"use strict";
/**
 * This example generates C# classes from the definitions in a OpenAPI JSON specification (models/petstore-simple.json).
 * The JSON file is taken from https://github.com/OAI/OpenAPI-Specification/blob/master/examples/v2.0/json/petstore-simple.json.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const templating_1 = require("@yellicode/templating");
const csharp_1 = require("@yellicode/csharp");
/**
 * A simple mapper function to turn a OpenAPI type name into a C# type name.
 * @param openApiTypeName
 */
const mapToCSharpTypeName = (openApiTypeName) => {
    switch (openApiTypeName) {
        case 'integer':
            return 'int';
        default:
            return openApiTypeName;
    }
};
templating_1.Generator.generateFromModel({ outputFile: './output/using-json-output.cs' }, (output, model) => {
    const classDefinitions = [];
    // Transform OpenAPI definitions to C# definitions
    for (const definition in model.definitions) {
        const value = model.definitions[definition];
        const classDefinition = { name: definition, accessModifier: 'public' };
        const classProperties = [];
        if ('properties' in value) {
            const properties = value['properties'];
            for (const prop in properties) {
                const propName = prop; // if you want UppperCase properties: const propName = NameUtility.lowerToUpperCamelCase(prop);
                const csTypename = mapToCSharpTypeName(properties[prop].type);
                classProperties.push({ name: propName, typeName: csTypename, accessModifier: "public" });
            }
        }
        classDefinition.properties = classProperties;
        classDefinitions.push(classDefinition);
    }
    // Then write code from the definition
    const csharp = new csharp_1.CSharpWriter(output);
    csharp.writeNamespaceBlock({ name: 'OpenApiSample' }, () => {
        // Write out the class properties
        classDefinitions.forEach(cd => {
            csharp.writeClassBlock(cd, () => {
                cd.properties.forEach(p => {
                    csharp.writeAutoProperty(p);
                    csharp.writeLine();
                });
            });
            csharp.writeLine();
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNpbmctanNvbi50ZW1wbGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInVzaW5nLWpzb24udGVtcGxhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRzs7QUFFSCxzREFBMkU7QUFDM0UsOENBQXNGO0FBRXRGOzs7R0FHRztBQUNILE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxlQUF1QixFQUFVLEVBQUU7SUFDNUQsUUFBUSxlQUFlLEVBQUU7UUFDckIsS0FBSyxTQUFTO1lBQ1YsT0FBTyxLQUFLLENBQUM7UUFDakI7WUFDSSxPQUFPLGVBQWUsQ0FBQztLQUM5QjtBQUNMLENBQUMsQ0FBQTtBQUVELHNCQUFTLENBQUMsaUJBQWlCLENBQUMsRUFBRSxVQUFVLEVBQUUsK0JBQStCLEVBQUUsRUFBRSxDQUFDLE1BQWtCLEVBQUUsS0FBVSxFQUFFLEVBQUU7SUFDNUcsTUFBTSxnQkFBZ0IsR0FBc0IsRUFBRSxDQUFDO0lBRS9DLGtEQUFrRDtJQUNsRCxLQUFLLE1BQU0sVUFBVSxJQUFJLEtBQUssQ0FBQyxXQUFXLEVBQUU7UUFDeEMsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM1QyxNQUFNLGVBQWUsR0FBb0IsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLGNBQWMsRUFBRSxRQUFRLEVBQUUsQ0FBQztRQUN4RixNQUFNLGVBQWUsR0FBeUIsRUFBRSxDQUFDO1FBQ2pELElBQUksWUFBWSxJQUFJLEtBQUssRUFBRTtZQUN2QixNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFdkMsS0FBSyxNQUFNLElBQUksSUFBSSxVQUFVLEVBQUU7Z0JBQzNCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxDQUFDLCtGQUErRjtnQkFDdEgsTUFBTSxVQUFVLEdBQUcsbUJBQW1CLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM5RCxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLGNBQWMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO2FBQzVGO1NBQ0o7UUFDRCxlQUFlLENBQUMsVUFBVSxHQUFHLGVBQWUsQ0FBQztRQUM3QyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7S0FDMUM7SUFFRCxzQ0FBc0M7SUFDdEMsTUFBTSxNQUFNLEdBQUcsSUFBSSxxQkFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3hDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsRUFBRSxHQUFHLEVBQUU7UUFDdkQsaUNBQWlDO1FBQ2pDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUMxQixNQUFNLENBQUMsZUFBZSxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUU7Z0JBQzVCLEVBQUUsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUN0QixNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzVCLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDdkIsQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztZQUNILE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQTtJQUNOLENBQUMsQ0FBQyxDQUFBO0FBQ04sQ0FBQyxDQUFDLENBQUMifQ==