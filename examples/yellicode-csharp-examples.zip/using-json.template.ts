/**
 * This example generates C# classes from the definitions in a OpenAPI JSON specification (models/petstore-simple.json). 
 * The JSON file is taken from https://github.com/OAI/OpenAPI-Specification/blob/master/examples/v2.0/json/petstore-simple.json.
 */

import { Generator, TextWriter, NameUtility } from '@yellicode/templating';
import { CSharpWriter, ClassDefinition, PropertyDefinition } from '@yellicode/csharp';

/**
 * A simple mapper function to turn a OpenAPI type name into a C# type name.
 * @param openApiTypeName 
 */
const mapToCSharpTypeName = (openApiTypeName: string): string => {
    switch (openApiTypeName) {
        case 'integer':
            return 'int';
        default:
            return openApiTypeName;
    }
}

Generator.generateFromModel({ outputFile: './output/using-json-output.cs' }, (output: TextWriter, model: any) => {
    const classDefinitions: ClassDefinition[] = [];

    // Transform OpenAPI definitions to C# definitions
    for (const definition in model.definitions) {
        const value = model.definitions[definition];
        const classDefinition: ClassDefinition = { name: definition, accessModifier: 'public' };
        const classProperties: PropertyDefinition[] = [];
        if ('properties' in value) {
            const properties = value['properties'];

            for (const prop in properties) {
                const propName = prop; // if you want UppperCase properties: const propName = NameUtility.lowerToUpperCamelCase(prop);
                const csTypename = mapToCSharpTypeName(properties[prop].type);
                classProperties.push({ name: propName, typeName: csTypename, accessModifier: "public" });
            }
        }
        classDefinition.properties = classProperties;
        classDefinitions.push(classDefinition);
    }

    // Then write code from the definition
    const csharp = new CSharpWriter(output);
    csharp.writeNamespaceBlock({ name: 'OpenApiSample' }, () => {
        // Write out the class properties
        classDefinitions.forEach(cd => {
            csharp.writeClassBlock(cd, () => {
                cd.properties.forEach(p => {
                    csharp.writeAutoProperty(p);
                    csharp.writeLine();
                });
            });
            csharp.writeLine();
        })
    })
});
