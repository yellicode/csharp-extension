/**
 * This example generates C# classes from definitions that are created inside the template itself.  
 */

import { TextWriter } from '@yellicode/core';
import { Generator } from '@yellicode/templating';
import { CSharpWriter, ClassDefinition, NamespaceDefinition } from '@yellicode/csharp';

Generator.generate({ outputFile: './output/using-code-output.cs' }, (output: TextWriter) => {

    const namespaceDefinition: NamespaceDefinition = { name: 'SampleNamespace' };

    // Sample class definition. You would typically create this definition from a JSON model, see 'using-json.template.ts'.
    const classDefinition: ClassDefinition = {
        name: 'Task',
        accessModifier: 'public',
        xmlDocSummary: ['Represents an activity to be done.']
    };

    classDefinition.properties = [
        { name: 'TaskDescription', typeName: 'string', accessModifier: 'public', xmlDocSummary: ['Gets or sets a description of the task.'] },
        { name: 'IsFinished', typeName: 'bool', accessModifier: 'public', xmlDocSummary: ['Indicates if the task is finished.'] }
    ];

    const csharp = new CSharpWriter(output);
    // Write the namespace
    csharp.writeNamespaceBlock(namespaceDefinition, () => {
        // Write out the class properties
        csharp.writeClassBlock(classDefinition, () => {
            classDefinition.properties.forEach(p => {
                csharp.writeAutoProperty(p);
                csharp.writeLine();
            })
        });
    })
});
