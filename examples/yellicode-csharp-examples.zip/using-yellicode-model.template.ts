/**
 * This example generates C# classes, interfaces, enumerations and structs from Yellicode model 'model/model-based-example.ymn'.  
 */

import { TextWriter } from '@yellicode/core';
import { Generator } from '@yellicode/templating';
import { CSharpWriter } from '@yellicode/csharp';
import * as elements from '@yellicode/elements';

Generator.generateFromModel({ outputFile: './output/using-yellicode-model-output.cs' }, (output: TextWriter, model: elements.Model) => {
    const csharp = new CSharpWriter(output);
    // Write a namespace with all contained types 
    csharp.writeNamespaceBlock(model, () => {
        // Classes
        csharp.writeNamespaceBlock({ name: 'Classes' }, () => {
            // Write all classes with their properties and methods.
            model.getAllClasses().forEach(cls => {
                csharp.writeClassBlock(cls, () => {
                    cls.ownedAttributes.forEach(att => {
                        csharp.writeAutoProperty(att);
                        csharp.writeLine();
                    });
                    cls.ownedOperations.forEach(op => {
                        csharp.writeMethodBlock(op, () => {
                            csharp.writeLine('// These are the method contents');
                        }, { isPartial: true });
                        csharp.writeLine();
                    });
                }, { isPartial: true });
                csharp.writeLine();
            });
        })

         // Enums
         csharp.writeLine();
         csharp.writeNamespaceBlock({ name: 'Enums' }, () => {            
            model.getAllEnumerations().forEach(e => {
                csharp.writeEnumeration(e);
                csharp.writeLine();
            });
        })

        // Interfaces
        csharp.writeLine();
        csharp.writeNamespaceBlock(({ name: 'Interfaces' }), () => {
            model.getAllInterfaces().forEach(i => {
                csharp.writeInterfaceBlock(i, () => {
                    i.ownedAttributes.forEach(att => {
                        csharp.writeAutoProperty(att);
                        csharp.writeLine();
                    });
                    i.ownedOperations.forEach(op => {
                        csharp.writeMethodDeclaration(op, { isPartial: true });
                        csharp.writeLine();
                    });
                }, { isPartial: true });
                csharp.writeLine();
            });
        });

        // Structs
        csharp.writeLine();
        csharp.writeNamespaceBlock({ name: 'Structs' }, () => {
            model.getAllDataTypes()
               .filter(dt => !elements.isEnumeration(dt)) // beause a Enumeration is a DataType too
               .forEach(dt => {
                csharp.writeStructBlock(dt, () => {
                    dt.ownedAttributes.forEach(att => {
                        csharp.writeAutoProperty(att);
                        csharp.writeLine();
                    });
                    dt.ownedOperations.forEach(op => {
                        csharp.writeMethodBlock(op, () => {
                            csharp.writeLine('// These are the method contents');
                        });
                        csharp.writeLine();
                    });
                });
            });
        });

    })
});     