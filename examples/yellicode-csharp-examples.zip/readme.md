# Yellicode C# samples
This is a collection of samples that demonstrate the Yellicode C# package. For running the samples, follow the instructions below. 

## Installation

### Prerequisites
In order to run a code generation template, you must have the CLI installed (@yellicode/cli) globally. You can install it as follows:

```
npm install @yellicode/cli -g
```

For opening the sample Yellicode model, you should install [Yellicode Modeler](https://www.yellicode.com/modeler). This is not required for running the examples.

### Install dependencies 
Install the required packages by running the `npm install` command.
```
npm install
```

## Running the samples
Run the `yellicode` or `yellicode --watch` command to run the samples. The C# files will be generated in the *output* directory.
```
yellicode
```

