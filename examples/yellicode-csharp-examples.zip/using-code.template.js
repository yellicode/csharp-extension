"use strict";
/**
 * This example generates C# classes from definitions that are created inside the template itself.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const templating_1 = require("@yellicode/templating");
const csharp_1 = require("@yellicode/csharp");
templating_1.Generator.generate({ outputFile: './output/using-code-output.cs' }, (output) => {
    const namespaceDefinition = { name: 'SampleNamespace' };
    // Sample class definition. You would typically create this definition from a JSON model, see 'using-json.template.ts'.
    const classDefinition = {
        name: 'Task',
        accessModifier: 'public',
        xmlDocSummary: ['Represents an activity to be done.']
    };
    classDefinition.properties = [
        { name: 'TaskDescription', typeName: 'string', accessModifier: 'public', xmlDocSummary: ['Gets or sets a description of the task.'] },
        { name: 'IsFinished', typeName: 'bool', accessModifier: 'public', xmlDocSummary: ['Indicates if the task is finished.'] }
    ];
    const csharp = new csharp_1.CSharpWriter(output);
    // Write the namespace
    csharp.writeNamespaceBlock(namespaceDefinition, () => {
        // Write out the class properties
        csharp.writeClassBlock(classDefinition, () => {
            classDefinition.properties.forEach(p => {
                csharp.writeAutoProperty(p);
                csharp.writeLine();
            });
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNpbmctY29kZS50ZW1wbGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInVzaW5nLWNvZGUudGVtcGxhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOztHQUVHOztBQUVILHNEQUE4RDtBQUM5RCw4Q0FBdUY7QUFFdkYsc0JBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxVQUFVLEVBQUUsK0JBQStCLEVBQUUsRUFBRSxDQUFDLE1BQWtCLEVBQUUsRUFBRTtJQUV2RixNQUFNLG1CQUFtQixHQUF3QixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxDQUFDO0lBRTdFLHVIQUF1SDtJQUN2SCxNQUFNLGVBQWUsR0FBb0I7UUFDckMsSUFBSSxFQUFFLE1BQU07UUFDWixjQUFjLEVBQUUsUUFBUTtRQUN4QixhQUFhLEVBQUUsQ0FBQyxvQ0FBb0MsQ0FBQztLQUN4RCxDQUFDO0lBRUYsZUFBZSxDQUFDLFVBQVUsR0FBRztRQUN6QixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLGNBQWMsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLENBQUMseUNBQXlDLENBQUMsRUFBRTtRQUNySSxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxjQUFjLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxDQUFDLG9DQUFvQyxDQUFDLEVBQUU7S0FDNUgsQ0FBQztJQUVGLE1BQU0sTUFBTSxHQUFHLElBQUkscUJBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN4QyxzQkFBc0I7SUFDdEIsTUFBTSxDQUFDLG1CQUFtQixDQUFDLG1CQUFtQixFQUFFLEdBQUcsRUFBRTtRQUNqRCxpQ0FBaUM7UUFDakMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUUsR0FBRyxFQUFFO1lBQ3pDLGVBQWUsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNuQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzVCLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUN2QixDQUFDLENBQUMsQ0FBQTtRQUNOLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUE7QUFDTixDQUFDLENBQUMsQ0FBQyJ9