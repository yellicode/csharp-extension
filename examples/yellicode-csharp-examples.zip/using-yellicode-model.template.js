"use strict";
/**
 * This example generates C# classes, interfaces, enumerations and structs from Yellicode model 'model/model-based-example.ymn'.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const templating_1 = require("@yellicode/templating");
const csharp_1 = require("@yellicode/csharp");
const elements = require("@yellicode/elements");
templating_1.Generator.generateFromModel({ outputFile: './output/using-yellicode-model-output.cs' }, (output, model) => {
    const csharp = new csharp_1.CSharpWriter(output);
    // Write a namespace with all contained types 
    csharp.writeNamespaceBlock(model, () => {
        // Classes
        csharp.writeNamespaceBlock({ name: 'Classes' }, () => {
            // Write all classes with their properties and methods.
            model.getAllClasses().forEach(cls => {
                csharp.writeClassBlock(cls, () => {
                    cls.ownedAttributes.forEach(att => {
                        csharp.writeAutoProperty(att);
                        csharp.writeLine();
                    });
                    cls.ownedOperations.forEach(op => {
                        csharp.writeMethodBlock(op, () => {
                            csharp.writeLine('// These are the method contents');
                        }, { isPartial: true });
                        csharp.writeLine();
                    });
                }, { isPartial: true });
                csharp.writeLine();
            });
        });
        // Enums
        csharp.writeLine();
        csharp.writeNamespaceBlock({ name: 'Enums' }, () => {
            model.getAllEnumerations().forEach(e => {
                csharp.writeEnumeration(e);
                csharp.writeLine();
            });
        });
        // Interfaces
        csharp.writeLine();
        csharp.writeNamespaceBlock(({ name: 'Interfaces' }), () => {
            model.getAllInterfaces().forEach(i => {
                csharp.writeInterfaceBlock(i, () => {
                    i.ownedAttributes.forEach(att => {
                        csharp.writeAutoProperty(att);
                        csharp.writeLine();
                    });
                    i.ownedOperations.forEach(op => {
                        csharp.writeMethodDeclaration(op, { isPartial: true });
                        csharp.writeLine();
                    });
                }, { isPartial: true });
                csharp.writeLine();
            });
        });
        // Structs
        csharp.writeLine();
        csharp.writeNamespaceBlock({ name: 'Structs' }, () => {
            model.getAllDataTypes()
                .filter(dt => !elements.isEnumeration(dt)) // beause a Enumeration is a DataType too
                .forEach(dt => {
                csharp.writeStructBlock(dt, () => {
                    dt.ownedAttributes.forEach(att => {
                        csharp.writeAutoProperty(att);
                        csharp.writeLine();
                    });
                    dt.ownedOperations.forEach(op => {
                        csharp.writeMethodBlock(op, () => {
                            csharp.writeLine('// These are the method contents');
                        });
                        csharp.writeLine();
                    });
                });
            });
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNpbmcteWVsbGljb2RlLW1vZGVsLnRlbXBsYXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidXNpbmcteWVsbGljb2RlLW1vZGVsLnRlbXBsYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7R0FFRzs7QUFFSCxzREFBOEQ7QUFDOUQsOENBQWlEO0FBQ2pELGdEQUFnRDtBQUVoRCxzQkFBUyxDQUFDLGlCQUFpQixDQUFDLEVBQUUsVUFBVSxFQUFFLDBDQUEwQyxFQUFFLEVBQUUsQ0FBQyxNQUFrQixFQUFFLEtBQXFCLEVBQUUsRUFBRTtJQUNsSSxNQUFNLE1BQU0sR0FBRyxJQUFJLHFCQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDeEMsOENBQThDO0lBQzlDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFO1FBQ25DLFVBQVU7UUFDVixNQUFNLENBQUMsbUJBQW1CLENBQUMsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUUsR0FBRyxFQUFFO1lBQ2pELHVEQUF1RDtZQUN2RCxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNoQyxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUU7b0JBQzdCLEdBQUcsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUM5QixNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQzlCLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDdkIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsR0FBRyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7d0JBQzdCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFOzRCQUM3QixNQUFNLENBQUMsU0FBUyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7d0JBQ3pELENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO3dCQUN4QixNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ3ZCLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUN4QixNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDdkIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQTtRQUVELFFBQVE7UUFDUixNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbkIsTUFBTSxDQUFDLG1CQUFtQixDQUFDLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRTtZQUNoRCxLQUFLLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ25DLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDM0IsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUE7UUFFRixhQUFhO1FBQ2IsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25CLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFO1lBQ3RELEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDakMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUU7b0JBQy9CLENBQUMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUM1QixNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQzlCLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDdkIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7d0JBQzNCLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQzt3QkFDdkQsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDO29CQUN2QixDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDeEIsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7UUFFSCxVQUFVO1FBQ1YsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25CLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxHQUFHLEVBQUU7WUFDakQsS0FBSyxDQUFDLGVBQWUsRUFBRTtpQkFDbkIsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMseUNBQXlDO2lCQUNuRixPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7Z0JBQ2IsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUU7b0JBQzdCLEVBQUUsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUM3QixNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQzlCLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDdkIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsRUFBRSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7d0JBQzVCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFOzRCQUM3QixNQUFNLENBQUMsU0FBUyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7d0JBQ3pELENBQUMsQ0FBQyxDQUFDO3dCQUNILE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDdkIsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBRVAsQ0FBQyxDQUFDLENBQUE7QUFDTixDQUFDLENBQUMsQ0FBQyJ9